#include "mainwindow.h"

#include <QApplication>
#include <QFile>


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Load the QSS file
    QFile styleFile(":/style.qss");  // If using Qt Resource System
    if (!styleFile.exists())
        styleFile.setFileName("style.qss");  // Fallback to same folder

    if (styleFile.open(QFile::ReadOnly)) {
        QString styleSheet = QLatin1String(styleFile.readAll());
        app.setStyleSheet(styleSheet);
    }

    MainWindow w;
    w.show();
    return app.exec();
}
