#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QVBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QTreeView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrl>
#include <QDebug>
#include <QFile>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Setup the UI
    setupUI();

    // Initialize network manager
    networkManager = new QNetworkAccessManager(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupUI()
{
    // Central widget and layout
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);

    // Title
    QLabel *titleLabel = new QLabel("MC Price Comparing", this);
    QFont titleFont = titleLabel->font();
    titleFont.setPointSize(16);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    titleLabel->setAlignment(Qt::AlignCenter);

    // Search input
    QLabel *searchLabel = new QLabel("Search Query:", this);
    searchInput = new QLineEdit(this);
    searchInput->setPlaceholderText("Enter search term (e.g., phone)");
    searchInput->setText("phone");

    // Search button
    searchButton = new QPushButton("Search eBay", this);
    searchButton->setMinimumHeight(40);
    connect(searchButton, &QPushButton::clicked, this, &MainWindow::onSearchButtonClicked);

    // Status label
    statusLabel = new QLabel("Ready", this);
    statusLabel->setStyleSheet("QLabel { color: green; }");

    // Result display
    QLabel *resultLabel = new QLabel("Results:", this);
    resultDisplay = new QTextEdit(this);
    resultDisplay->setReadOnly(true);

    // Price comparison tree
    QLabel *comparisonLabel = new QLabel("Price Comparison:", this);
    priceComparisonList = new QTreeView(this);
    setupComparisonList();

    // Add widgets to layout
    layout->addWidget(titleLabel);
    layout->addSpacing(10);
    layout->addWidget(searchLabel);
    layout->addWidget(searchInput);
    layout->addWidget(searchButton);
    layout->addWidget(statusLabel);
    layout->addSpacing(10);
    layout->addWidget(resultLabel);
    layout->addWidget(resultDisplay);
    layout->addSpacing(10);
    layout->addWidget(comparisonLabel);
    layout->addWidget(priceComparisonList);

    // Set central widget
    setCentralWidget(centralWidget);

    // Window properties
    setWindowTitle("eBay API Client");
    resize(800, 600);


}

void MainWindow::setupComparisonList()
{
    priceModel = new QStandardItemModel(this);
    priceModel->setColumnCount(2);
    priceModel->setHorizontalHeaderLabels({"Store", "Price"});

    QList<QPair<QString, QString>> storeData = {
        {"Amazon", "$--"},
        {"Walmart", "$--"},
        {"Best Buy", "$--"},
        {"eBay", "$--"}
    };

    for (const auto &pair : storeData)
    {
        QList<QStandardItem*> row;
        row.append(new QStandardItem(pair.first));
        row.append(new QStandardItem(pair.second));
        priceModel->appendRow(row);
    }

    priceComparisonList->setModel(priceModel);
    priceComparisonList->setHeaderHidden(false);
    priceComparisonList->setRootIsDecorated(false);
    priceComparisonList->setEditTriggers(QAbstractItemView::NoEditTriggers);
    priceComparisonList->setSelectionMode(QAbstractItemView::NoSelection);
    priceComparisonList->setColumnWidth(0, 150);
    priceComparisonList->setColumnWidth(1, 100);
}

void MainWindow::updateStorePrice(const QString &storeName, const QString &price)
{
    if (!priceModel) return;

    for (int row = 0; row < priceModel->rowCount(); ++row)
    {
        QStandardItem *storeItem = priceModel->item(row, 0);
        if (storeItem && storeItem->text().compare(storeName, Qt::CaseInsensitive) == 0)
        {
            QStandardItem *priceItem = priceModel->item(row, 1);
            if (priceItem)
                priceItem->setText("$" + price);
            break;
        }
    }
}

void MainWindow::onSearchButtonClicked()
{
    QString query = searchInput->text().trimmed();

    if(query.isEmpty())
    {
        statusLabel->setText("Error: Please enter a search query");
        statusLabel->setStyleSheet("QLabel { color: red; }");
        return;
    }

    statusLabel->setText("Searching...");
    statusLabel->setStyleSheet("QLabel { color: blue; }");
    resultDisplay->clear();
    resultDisplay->append("Sending request to eBay API...\n");

    getEbayPrice(query);
}

void MainWindow::getEbayPrice(const QString &productName)
{
    // For simplicity, use your OAuth token directly here
    QString token = "v^1.1#i^1#f^0#p^1#r^0#I^3#t^H4sIAAAAAAAA/+VYW2wUVRju9mYbbkpJQVCzDl4CZGbPzN5HuqQXLgu9wVZSGg2emTnbDp2dWeacod3Gy9IIEXkAQywGQTAhVeBB4gOCicQHrYIGQUFjLBFeFE0QVEB4MZ7ZXcq2Eih01U3cZDM55/z/f/7/O//tHJAsLZ+9ftH6PyY47inclQTJQoeDHwfKS0vmTCwqnF5SALIIHLuSjySLe4vOzcUwpsXFZQjHDR0jZ3dM07GYmqxiLFMXDYhVLOowhrBIZDFS3VAvChwQ46ZBDNnQGGe4ropBAQBgwKMEZR/vo386q1+X2WJUMQKQBR66vYh3I94fgHQdYwuFdUygTux1wcvyPAuCLQIQ3R5R8HAe3tfGOJcjE6uGTkk4wIRS6oopXjNL11urCjFGJqFCmFC4ekGkqTpcN7+xZa4rS1Yog0OEQGLh4aNaQ0HO5VCz0K23wSlqMWLJMsKYcYXSOwwXKlZfV+Yu1E9BzQekoBcJfh8fFRTB680JlAsMMwbJrfWwZ1SFjaZIRaQTlSRuhyhFQ1qFZJIZNVIR4Tqn/VlqQU2NqsisYubXVK+obm5mQrUd0NQQXsw21Dabqoxq2UhNK6vwgs8XgHyAVYK8PwqiMLNRWloG5hE71Rq6otqgYWejQWoQ1RqNxEbIwoYSNelNZnWU2Bpl0wlDGII2+1DTp2iRDt0+VxSjQDhTw9ufwBA3IaYqWQQNSRi5kIKoioHxuKowIxdTvphxn25cxXQQEhddrq6uLq7LzRlmu0sAgHe1NtRH5A4Uo8HWHbNjPU2v3p6BVVOmyIhyYlUkiTjVpZv6KlVAb2dCHh/g/b4M7sPVCo2c/dtEls2u4RGRqwiRAkiCbt4v8UBBUMpFgIQyPuqy1aDSE2wMmp2IxDUoI1ambmbFkKkqotsbFdyBKGIVXzDKeoLRKCt5FR/LRxECCEmSHAz8n+JktJ4eQbKJSE5cPWduPn/1UhKuaW3sdPHhVjyHN1sD4Zgnvmqhi7jql3RjTbO8Zi0UelZ5qkYbDDc1vlZTKTItdP/8i/VFBiZIGZN5EdmIo2ZDU+VEfh2w21SaoUkSNVaCjiNI0+hnTKZWx+Ph3CTsnBl5h8ni7uzOXaH6j4rUTa3CtuPml1U2P6YCYFzl7DpkxzonGzGXAWkPYk+vTGntHEl4MyKXZCW4dgthQjVRaBs4aiaVJnOOljRl9CzpgkmNGD0LvWMolkzuaqNUZeYommp7B8F3tGf3WECRLK1z9Cy0P9FGR03naIdBTbLBkKDcyZkIKoauJcbk4iq9qeSVg1M70yCoSvqKwaWQ4PAamVqMDYtigLkmu+NuMTqRThsYYhqahszl/JhTdyxmEShpKN9yeDqX0VifOLbDhnnWYVGjBL8APD7PmOySU/3TynyrQP9K5V1GM0gsv+zGUFcko/sfuB+6hr9WhQpSP77XcRT0OgYKHQ5QB1h+DphVWvRkcdF4BtOUzGXU4VQY5Wg10CGxTMR1okQcqmZhRcHJnzdHVpxYcrDvcM/qtdy8gYLyrEezXU+DaUPPZuVF/LisNzTwwI2VEn7S1AmCl+dBUABuj+BpAzNvrBbzlcVTruw7px1d4xzft/ezenOj/OBTDVAGE4aIHI6SguJeR0FZUoBTdlQeSYLQijrD+8XkNf1Lj5XVnwA/DS7+c+qk0uTutiMHFr9Stq7utOl7Sd16cWXZstPjN50fGHjsQtcHFXuu8vdt3bi3b9ZHG/q/7X0/wZZ+8taLp5hf5be9ZT+CeU2vH6x87eL2Q84zl46/+9u9+3cXFq37ffDM7FO9V5qP9bQ39rzBT9xW9HhJx0PzdlzbeT7of/NqvzD4zDs/TO/f0jhp34yrnRWfr+2b7Hn5+7OXtEXSnlMXDyw8dLbYWWjKMz9cO+7kx55nH952/6s9G3Zem/FC6Dn1681PVFwr8D96uearmm9ObPryvS2r92//tGtgfWK6b9oh9fnNh4/7frnQtmFn5cvWdz2DxuXK9Jn+BV7XECzOFAAA";
    if (token.isEmpty())
    {
        qDebug() << "No token available. Aborting API call.";
        return;
    }

    QString query = productName;
    query.replace(" ", "+");
    QString urlString = "https://api.sandbox.ebay.com/buy/browse/v1/item_summary/search?q=" + query;
    QUrl url(urlString);

    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", "Bearer " + token.toUtf8());

    QNetworkReply *reply = networkManager->get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply, productName]() {
        if (reply->error() == QNetworkReply::NoError)
        {
            QByteArray response = reply->readAll();
            QJsonDocument doc = QJsonDocument::fromJson(response);
            QJsonObject root = doc.object();

            resultDisplay->append("=== eBay Search Results ===\n");

            if (root.contains("itemSummaries"))
            {
                QJsonArray items = root["itemSummaries"].toArray();
                if (!items.isEmpty())
                {
                    QJsonObject firstItem = items.first().toObject();
                    QString title = firstItem["title"].toString();
                    QString price = firstItem["price"].toObject()["value"].toString();
                    QString currency = firstItem["price"].toObject()["currency"].toString();

                    resultDisplay->append(QString("Title: %1").arg(title));
                    resultDisplay->append(QString("Price: %1 %2").arg(price, currency));

                    // Update price in comparison list
                    updateStorePrice("eBay", price);
                }
                else
                {
                    resultDisplay->append("No items found.");
                    updateStorePrice("eBay", "--");
                }
            }
            else
            {
                resultDisplay->append("No items found or API error.");
                updateStorePrice("eBay", "--");
            }
        }
        else
        {
            resultDisplay->append("Network Error: " + reply->errorString());
            updateStorePrice("eBay", "--");
        }

        reply->deleteLater();
        statusLabel->setText("Search completed");
        statusLabel->setStyleSheet("QLabel { color: green; }");
    });
}
