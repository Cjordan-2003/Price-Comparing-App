#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QLabel>
#include <QTreeView>
#include <QStandardItemModel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onSearchButtonClicked();

private:
    void setupUI();
    void setupComparisonList();
    void updateStorePrice(const QString &storeName, const QString &price);
    void getEbayPrice(const QString &productName);

    Ui::MainWindow *ui;
    QNetworkAccessManager *networkManager;

    // UI Elements
    QLineEdit *searchInput;
    QPushButton *searchButton;
    QTextEdit *resultDisplay;
    QLabel *statusLabel;
    QTreeView *priceComparisonList;
    QStandardItemModel *priceModel;
};

#endif // MAINWINDOW_H
